// javascript for registration

    let fname = document.getElementById("fname");
    let lname = document.getElementById("lname");
    let pass = document.getElementById("pass");
    let repass = document.getElementById("repass");
    let gender = document.getElementById("gender");
    let email = document.getElementById("email");
    let phone = document.getElementById("phone");
    let agree = document.getElementById("agree");
    let status=0;

    function showpass1(){
        var input1 = document.getElementById("pass");

        if(input1.type === "password")input1.type = "text";
        else input1.type = "password";
    }

    function showpass2(){
        var input2 = document.getElementById("repass");

        if(input2.type === "password")input2.type = "text";
        else input2.type = "password";
    }

    function getAction() {
        if(firstnamevalidation(fname)==true)status++;
        if(lastnamevalidation(lname)==true)status++;
        if(passvalidation(pass)==true)status++;
        if(repassvalidation(repass,pass)==true)status++;
        if(gendervalidation(gender)==true)status++;
        if(emailvalidation(email)==true)status++;
        if(phonevalidation(phone)==true)status++;
        if(agreevalidation(agree)==true)status++;
        
        //if some of or all validation(s) is/are incorrect form
        if(status==8){
            alert("Thankyou "+fname.value+" for registering!");
            status=0;
            window.location.href = "Index.html";
            window.alert("Registered!");
        }
        // //if all validations are correct form
        else{
            alert("Please check again your inputted data!");
            status=0;
        } 
            
    }

    function firstnamevalidation(fname){
            var terms=/^[a-z A-Z]+$/;
        
            if(fname.value.match(terms)){
                document.getElementById("first-name-error").innerHTML = "";
                return true;
            } 
            else{
                document.getElementById("first-name-error").innerHTML = "Please input your first name correctly!";
                return false;
            }
    }

    function lastnamevalidation(lname){
        var terms=/^[a-z A-Z]+$/;
        
        if(lname.value.match(terms)){
            document.getElementById("last-name-error").innerHTML = "";
            return true;
        } 
        else{
            document.getElementById("last-name-error").innerHTML = "Please input your last name correctly!";
            return false;
        }
    }

    function passvalidation(pass){
        let checkerNumber=0;
        let checkerCapital=0;
        let checkerStandart=0;
        
        var termsnumber = /^[0-9]+$/;
        var termscap = /^[A-Z]+$/;
        var termsstan = /^[a-z]+$/;

        for (let i = 0; i < pass.value.length; i++) {
            if(pass.value[i].match(termsnumber))checkerNumber=1;
            if(pass.value[i].match(termscap))checkerCapital=1;
            if(pass.value[i].match(termsstan))checkerStandart=1;
        }

        if(pass.value==""){
            document.getElementById("password-error").innerHTML = "Please input your password!";
            return false;
        }
        else if(checkerNumber==0 || checkerCapital==0 || checkerStandart==0){
            document.getElementById("password-error").innerHTML = "Please input the password according to the terms! Ex:Password123 (must incude number, capital alphabet, and normal alphabet";
            return false;
        }
        else{
            document.getElementById("password-error").innerHTML = "";
            return true;
        } 
    }
    
    function repassvalidation(repass,pass){
        let checkerNumber=0;
        let checkerCapital=0;
        let checkerStandart=0;
        
        var termsnumber = /^[0-9]+$/;
        var termscap = /^[A-Z]+$/;
        var termsstan = /^[a-z]+$/;

        for (let i = 0; i < repass.value.length; i++) {
            if(repass.value[i].match(termsnumber))checkerNumber=1;
            if(repass.value[i].match(termscap))checkerCapital=1;
            if(repass.value[i].match(termsstan))checkerStandart=1;
        }

        if(repass.value==""){
            document.getElementById("confirm-password-error").innerHTML = "Please input your confirmation password!";
            return false;
        }
        else if(repass.value!==pass.value){
            document.getElementById("confirm-password-error").innerHTML ="The confirmation password is wrong! Please check your confirmation password again!";
            return false;
        }
        else{
            document.getElementById("confirm-password-error").innerHTML = "";
            return true;
        } 
    }

    function gendervalidation(gender){
        if(gender.value==0){
            document.getElementById("gender-error").innerHTML="Please select gender";
            return false;
        }
        else{
            document.getElementById("gender-error").innerHTML="";
            return true;
        }
    }

    function emailvalidation(email){
        if (email.value == "") {
            document.getElementById("email-error").innerHTML="Please input your email!";
            return false;
        } 
        else if(!email.value.includes("@")) {
            document.getElementById("email-error").innerHTML="Email must include '@'!";
            return false;
        } 
        else if(email.value.startsWith("@")) {
            document.getElementById("email-error").innerHTML="Email cannot start with '@'!";
            return false;
        } 
        else if(email.value.endsWith("@")) {
            document.getElementById("email-error").innerHTML="Email cannot end with '@'!";
            return false;
        } 
        else if(!email.value.endsWith(".com")&&!email.value.endsWith(".edu")&&!email.value.endsWith(".co.id")&&!email.value.endsWith(".ac.id")&&!email.value.endsWith(".org")) {
            document.getElementById("email-error").innerHTML="Email must end with '.com' or '.edu' or '.co.id' or '.ac.id' or '.org'!";
            return false;
        } 
        else if(email.value.indexOf("@") != email.value.lastIndexOf("@")) {
            document.getElementById("email-error").innerHTML="Email only have one '@'!";
            return false;
        }
        else{
            document.getElementById("email-error").innerHTML="";
            return true;
        } 
    }

    function phonevalidation(phone){
        if(phone.value==""){
            document.getElementById("phone-error").innerHTML="Please input your phone number correctly! (numeric only)";
            return false;
        }
        else if(phone.value.length<10||phone.value.length>15){
            document.getElementById("phone-error").innerHTML="Please input your phone number correctly! (between 10-15)";
            return false;
        }
        else {
            document.getElementById("phone-error").innerHTML="";
            return true;
        } 
    }

    function agreevalidation(){

        if (!agree.checked) {
            document.getElementById("agree-error").innerHTML="You must agree to the terms and conditions";
            return false;
        }
        else {
            document.getElementById("agree-error").innerHTML="";
            return true;
        }
    }
